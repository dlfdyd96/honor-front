<template>
    <div id='main'>
        <div class="image" >
            <img src="../assets/bm.png">
        </div>
    </div>
</template>

<script>
    export default {
        
    }
</script>

<style scoped>
    #main{
      width:100%;
      height:100%;
      background-color: rgb(233, 236, 241);
    }
    .image {
        width:70%;
        text-align: center;
        margin:0px auto;
    }
    .image img {
        width:100%;
        height:auto;
    }

</style>