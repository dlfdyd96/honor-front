<template>
  <div>
	<span>collection</span>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>