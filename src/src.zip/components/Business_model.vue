<template>
    <div class='main'>
        <div class="image" >
            <img src="../assets/bm.png">
        </div>
    </div>
</template>

<script>
    export default {
        
    }
</script>

<style scoped>
    .main{
        display: table;
        height: 100vh;
        margin: auto;
    }
    .image{
        display: table-cell;
        vertical-align: middle; 
    }
    img {
        width:60vw;
        height: auto;
    }

</style>