<template>
	<div>
		구매가 완료되셨습니다. 
		<p/>아래의 계좌로 15분 내로 입금 해주세요. <p/>입금하지 않을 경우 구매가 취소됩니다.
		<p/>
		(xx은행)000-00000-00000-00 예금주 : xxx

	</div>
</template>

<script>
export default {

}
</script>

<style>

</style>